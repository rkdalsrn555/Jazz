﻿CREATE TABLE `Member` (
	`id`	VARCHAR(36)	NOT NULL,
	`user_id`	VARCHAR(30)	NOT NULL,
	`pw`	VARCHAR(256)	NOT NULL,
	`salt`	VARCHAR(256)	NOT NULL,
	`created_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP,
	`updated_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP
);

CREATE TABLE `Token` (
	`member_id`	VARCHAR(36)	NOT NULL,
	`refresh_token`	VARCHAR(256)	NOT NULL
);

CREATE TABLE `Profile` (
	`member_id`	VARCHAR(36)	NOT NULL,
	`nickname`	VARCHAR(12)	NOT NULL,
	`diamond`	INT	NOT NULL	DEFAULT 0,
	`created_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP,
	`updated_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP
);

CREATE TABLE `Quiz` (
	`id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`question`	VARCHAR(100)	NOT NULL,
	`kind`	TINYINT	NOT NULL
);

CREATE TABLE `Case` (
	`case_num`	INT	NOT NULL,
	`quiz_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`content`	VARCHAR(50)	NOT NULL,
	`is_multi`	BOOLEAN	NOT NULL	DEFAULT FALSE
);

CREATE TABLE `Enterprise` (
	`id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`code`	VARCHAR(8)	NOT NULL,
	`name`	VARCHAR(50)	NOT NULL,
	`rcept_no`	VARCHAR(14)	NOT NULL
);

CREATE TABLE `FinancialPosition` (
	`ord`	INT	NOT NULL,
	`enterprise_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`account_name`	VARCHAR(100)	NULL,
	`thstrm_name`	VARCHAR(100)	NULL,
	`th_amount`	BIGINT	NULL,
	`frmtrm_name`	VARCHAR(100)	NULL,
	`frm_ammount`	BIGINT	NULL
);

CREATE TABLE `ComprehensiveIncome` (
	`ord`	INT	NOT NULL,
	`enterprise_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`account_name`	VARCHAR(100)	NULL,
	`thstrm_name`	VARCHAR(100)	NULL,
	`th_amount`	BIGINT	NULL,
	`frmtrm_name`	VARCHAR(100)	NULL,
	`frm_ammount`	BIGINT	NULL
);

CREATE TABLE `ChangeInEquity` (
	`point_time_name`	VARCHAR(100)	NOT NULL,
	`enterprise_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`account_name`	VARCHAR(100)	NULL,
	`account_detail`	VARCHAR(100)	NULL,
	`amount`	BIGINT	NULL
);

CREATE TABLE `CashFlow` (
	`ord`	INT	NOT NULL,
	`enterprise_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`account_name`	VARCHAR(100)	NULL,
	`thstrm_name`	VARCHAR(100)	NULL,
	`th_amount`	BIGINT	NULL,
	`frmtrm_name`	VARCHAR(100)	NULL,
	`frm_ammount`	BIGINT	NULL
);

CREATE TABLE `FinancialGraph` (
	`point_time_name`	VARCHAR(20)	NOT NULL,
	`enterprise_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`total_assets`	BIGINT	NULL,
	`total_debt`	BIGINT	NULL,
	`total_capital`	BIGINT	NULL,
	`income`	BIGINT	NULL,
	`total_comprehensive_income`	BIGINT	NULL,
	`created_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP,
	`updated_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP
);

CREATE TABLE `IncomeStatement` (
	`point_time_name`	VARCHAR(100)	NOT NULL,
	`enterprise_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`account_name`	VARCHAR(100)	NULL,
	`thstrm_name`	VARCHAR(100)	NULL,
	`th_amount`	BIGINT	NULL,
	`frmtrm_name`	VARCHAR(100)	NULL,
	`frm_ammount`	BIGINT	NULL
);

CREATE TABLE `Record` (
	`member_id`	VARCHAR(36)	NOT NULL,
	`season_id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`exp_point`	INT	NOT NULL	DEFAULT 0,
	`rank_point`	INT	NOT NULL	DEFAULT 0,
	`quiz_record`	SMALLINT	NOT NULL	DEFAULT 0,
	`win`	SMALLINT	NOT NULL	DEFAULT 0,
	`draw`	SMALLINT	NOT NULL	DEFAULT 0,
	`lose`	SMALLINT	NOT NULL	DEFAULT 0,
	`created_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP,
	`updated_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP
);

CREATE TABLE `QuizManagement` (
	`member_id`	VARCHAR(36)	NOT NULL,
	`quiz_id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`is_correct`	BOOLEAN	NOT NULL	DEFAULT FALSE,
	`is_bookmark`	BOOLEAN	NOT NULL	DEFAULT FALSE
);

CREATE TABLE `Explanation` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`word`	VARCHAR(20)	NOT NULL,
	`description`	VARCHAR(256)	NOT NULL
);

CREATE TABLE `Item` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`price`	INT	NOT NULL,
	`kind`	ENUM	NOT NULL	DEFAULT 4	COMMENT '4 :  캐릭터

--------- 여기선 캐릭터만 사용
1 : 다이아
2 : 접두사
3 : 접미사'
);

CREATE TABLE `PreTitle` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`degree`	SMALLINT	NOT NULL,
	`content`	VARCHAR(10)	NOT NULL
);

CREATE TABLE `SuffixTitle` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`degree`	SMALLINT	NOT NULL,
	`content`	VARCHAR(10)	NOT NULL
);

CREATE TABLE `ItemManagement` (
	`member_id`	VARCHAR(36)	NOT NULL,
	`item_id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`is_own`	BOOLEAN	NOT NULL	DEFAULT FALSE	COMMENT '기본캐릭터 TRUE',
	`is_used`	BOOLEAN	NOT NULL	DEFAULT FALSE	COMMENT '기본캐릭터 TRUE'
);

CREATE TABLE `PreTitleManagement` (
	`pre_title_id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`member_id`	VARCHAR(36)	NOT NULL,
	`is_own`	BOOLEAN	NOT NULL	DEFAULT FALSE,
	`is_used`	BOOLEAN	NOT NULL	DEFAULT FALSE
);

CREATE TABLE `SuffixTitleManagement` (
	`suffix_title_id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`member_id`	VARCHAR(36)	NOT NULL,
	`is_own`	BOOLEAN	NOT NULL	DEFAULT FALSE,
	`is_used`	BOOLEAN	NOT NULL	DEFAULT FALSE
);

CREATE TABLE `Season` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`start_date`	TIMESTAMP	NOT NULL,
	`end_date`	TIMESTAMP	NOT NULL
);

CREATE TABLE `Mail` (
	`id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`member_id`	VARCHAR(36)	NOT NULL,
	`reward_type`	ENUM	NOT NULL	DEFAULT 1	COMMENT '1 : 다이아
2 : 접두사
3: 접미사',
	`pretitle_id`	SMALLINT	NULL	DEFAULT AUTO_INCREMENT,
	`subtitle_id`	SMALLINT	NULL	DEFAULT AUTO_INCREMENT,
	`diamond_amount`	SMALLINT	NULL,
	`content`	ENUM	NOT NULL	DEFAULT 1,
	`is_check`	BOOLEAN	NOT NULL	DEFAULT FALSE,
	`created_at`	TIMESTAMP	NOT NULL,
	`updated_at`	TIMESTAMP	NOT NULL
);

CREATE TABLE `CopyOfMailbox` (
	`id`	INT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`id2`	VARCHAR(36)	NOT NULL,
	`reward_type`	ENUM	NOT NULL	DEFAULT 1	COMMENT '1 : 다이아
2 : 접두사
3: 접미사',
	`diamond_amount`	SMALLINT	NULL,
	`content`	ENUM	NOT NULL	DEFAULT 1,
	`is_check`	BOOLEAN	NOT NULL	DEFAULT FALSE,
	`created_at`	TIMESTAMP	NOT NULL,
	`updated_at`	TIMESTAMP	NOT NULL
);

CREATE TABLE `CopyOfSuffixTitleManagement` (
	`is_own`	BOOLEAN	NOT NULL	DEFAULT FALSE,
	`is_used`	BOOLEAN	NOT NULL	DEFAULT FALSE
);

CREATE TABLE `CopyOfPreTitleManagement` (
	`is_own`	BOOLEAN	NOT NULL	DEFAULT FALSE,
	`is_used`	BOOLEAN	NOT NULL	DEFAULT FALSE
);

CREATE TABLE `CopyOfPreTitle2` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`degree`	SMALLINT	NOT NULL,
	`content`	VARCHAR(10)	NOT NULL
);

CREATE TABLE `CopyOfSuffixTitle2` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`degree`	SMALLINT	NOT NULL,
	`content`	VARCHAR(10)	NOT NULL
);

CREATE TABLE `CopyOfItem` (
	`id`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`price`	INT	NOT NULL,
	`kind`	ENUM	NOT NULL	DEFAULT 1	COMMENT '1  : 없음
2 : 접두사
3 : 접미사
4 : 캐릭터',
	`degree`	VARCHAR(255)	NULL
);

CREATE TABLE `CopyOfItemManagement` (
	`id2`	SMALLINT	NOT NULL	DEFAULT AUTO_INCREMENT,
	`id`	VARCHAR(36)	NOT NULL,
	`is_own`	BOOLEAN	NOT NULL	DEFAULT FALSE	COMMENT '기본캐릭터 TRUE',
	`is_used`	BOOLEAN	NOT NULL	DEFAULT FALSE	COMMENT '기본캐릭터 TRUE'
);

CREATE TABLE `CopyOfMember` (
	`id`	VARCHAR(36)	NOT NULL,
	`user_id`	VARCHAR(30)	NOT NULL,
	`pw`	VARCHAR(256)	NOT NULL,
	`salt`	VARCHAR(256)	NOT NULL,
	`created_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP,
	`updated_at`	TIMESTAMP	NOT NULL	DEFAULT TIMESTAMP
);

ALTER TABLE `Member` ADD CONSTRAINT `PK_MEMBER` PRIMARY KEY (
	`id`
);

ALTER TABLE `Token` ADD CONSTRAINT `PK_TOKEN` PRIMARY KEY (
	`member_id`
);

ALTER TABLE `Profile` ADD CONSTRAINT `PK_PROFILE` PRIMARY KEY (
	`member_id`
);

ALTER TABLE `Quiz` ADD CONSTRAINT `PK_QUIZ` PRIMARY KEY (
	`id`
);

ALTER TABLE `Case` ADD CONSTRAINT `PK_CASE` PRIMARY KEY (
	`case_num`,
	`quiz_id`
);

ALTER TABLE `Enterprise` ADD CONSTRAINT `PK_ENTERPRISE` PRIMARY KEY (
	`id`
);

ALTER TABLE `FinancialPosition` ADD CONSTRAINT `PK_FINANCIALPOSITION` PRIMARY KEY (
	`ord`,
	`enterprise_id`
);

ALTER TABLE `ComprehensiveIncome` ADD CONSTRAINT `PK_COMPREHENSIVEINCOME` PRIMARY KEY (
	`ord`,
	`enterprise_id`
);

ALTER TABLE `ChangeInEquity` ADD CONSTRAINT `PK_CHANGEINEQUITY` PRIMARY KEY (
	`point_time_name`,
	`enterprise_id`
);

ALTER TABLE `CashFlow` ADD CONSTRAINT `PK_CASHFLOW` PRIMARY KEY (
	`ord`,
	`enterprise_id`
);

ALTER TABLE `FinancialGraph` ADD CONSTRAINT `PK_FINANCIALGRAPH` PRIMARY KEY (
	`point_time_name`,
	`enterprise_id`
);

ALTER TABLE `IncomeStatement` ADD CONSTRAINT `PK_INCOMESTATEMENT` PRIMARY KEY (
	`point_time_name`,
	`enterprise_id`
);

ALTER TABLE `Record` ADD CONSTRAINT `PK_RECORD` PRIMARY KEY (
	`member_id`,
	`season_id`
);

ALTER TABLE `QuizManagement` ADD CONSTRAINT `PK_QUIZMANAGEMENT` PRIMARY KEY (
	`member_id`,
	`quiz_id`
);

ALTER TABLE `Explanation` ADD CONSTRAINT `PK_EXPLANATION` PRIMARY KEY (
	`id`
);

ALTER TABLE `Item` ADD CONSTRAINT `PK_ITEM` PRIMARY KEY (
	`id`
);

ALTER TABLE `PreTitle` ADD CONSTRAINT `PK_PRETITLE` PRIMARY KEY (
	`id`
);

ALTER TABLE `SuffixTitle` ADD CONSTRAINT `PK_SUFFIXTITLE` PRIMARY KEY (
	`id`
);

ALTER TABLE `ItemManagement` ADD CONSTRAINT `PK_ITEMMANAGEMENT` PRIMARY KEY (
	`member_id`,
	`item_id`
);

ALTER TABLE `PreTitleManagement` ADD CONSTRAINT `PK_PRETITLEMANAGEMENT` PRIMARY KEY (
	`pre_title_id`,
	`member_id`
);

ALTER TABLE `SuffixTitleManagement` ADD CONSTRAINT `PK_SUFFIXTITLEMANAGEMENT` PRIMARY KEY (
	`suffix_title_id`,
	`member_id`
);

ALTER TABLE `Season` ADD CONSTRAINT `PK_SEASON` PRIMARY KEY (
	`id`
);

ALTER TABLE `Mail` ADD CONSTRAINT `PK_MAIL` PRIMARY KEY (
	`id`,
	`member_id`
);

ALTER TABLE `CopyOfMailbox` ADD CONSTRAINT `PK_COPYOFMAILBOX` PRIMARY KEY (
	`id`,
	`id2`
);

ALTER TABLE `CopyOfPreTitle2` ADD CONSTRAINT `PK_COPYOFPRETITLE2` PRIMARY KEY (
	`id`
);

ALTER TABLE `CopyOfSuffixTitle2` ADD CONSTRAINT `PK_COPYOFSUFFIXTITLE2` PRIMARY KEY (
	`id`
);

ALTER TABLE `CopyOfItem` ADD CONSTRAINT `PK_COPYOFITEM` PRIMARY KEY (
	`id`
);

ALTER TABLE `CopyOfItemManagement` ADD CONSTRAINT `PK_COPYOFITEMMANAGEMENT` PRIMARY KEY (
	`id2`,
	`id`
);

ALTER TABLE `CopyOfMember` ADD CONSTRAINT `PK_COPYOFMEMBER` PRIMARY KEY (
	`id`
);

ALTER TABLE `Token` ADD CONSTRAINT `FK_Member_TO_Token_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `Profile` ADD CONSTRAINT `FK_Member_TO_Profile_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `Case` ADD CONSTRAINT `FK_Quiz_TO_Case_1` FOREIGN KEY (
	`quiz_id`
)
REFERENCES `Quiz` (
	`id`
);

ALTER TABLE `FinancialPosition` ADD CONSTRAINT `FK_Enterprise_TO_FinancialPosition_1` FOREIGN KEY (
	`enterprise_id`
)
REFERENCES `Enterprise` (
	`id`
);

ALTER TABLE `ComprehensiveIncome` ADD CONSTRAINT `FK_Enterprise_TO_ComprehensiveIncome_1` FOREIGN KEY (
	`enterprise_id`
)
REFERENCES `Enterprise` (
	`id`
);

ALTER TABLE `ChangeInEquity` ADD CONSTRAINT `FK_Enterprise_TO_ChangeInEquity_1` FOREIGN KEY (
	`enterprise_id`
)
REFERENCES `Enterprise` (
	`id`
);

ALTER TABLE `CashFlow` ADD CONSTRAINT `FK_Enterprise_TO_CashFlow_1` FOREIGN KEY (
	`enterprise_id`
)
REFERENCES `Enterprise` (
	`id`
);

ALTER TABLE `FinancialGraph` ADD CONSTRAINT `FK_Enterprise_TO_FinancialGraph_1` FOREIGN KEY (
	`enterprise_id`
)
REFERENCES `Enterprise` (
	`id`
);

ALTER TABLE `IncomeStatement` ADD CONSTRAINT `FK_Enterprise_TO_IncomeStatement_1` FOREIGN KEY (
	`enterprise_id`
)
REFERENCES `Enterprise` (
	`id`
);

ALTER TABLE `Record` ADD CONSTRAINT `FK_Member_TO_Record_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `Record` ADD CONSTRAINT `FK_Season_TO_Record_1` FOREIGN KEY (
	`season_id`
)
REFERENCES `Season` (
	`id`
);

ALTER TABLE `QuizManagement` ADD CONSTRAINT `FK_Member_TO_QuizManagement_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `QuizManagement` ADD CONSTRAINT `FK_Quiz_TO_QuizManagement_1` FOREIGN KEY (
	`quiz_id`
)
REFERENCES `Quiz` (
	`id`
);

ALTER TABLE `ItemManagement` ADD CONSTRAINT `FK_Member_TO_ItemManagement_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `ItemManagement` ADD CONSTRAINT `FK_Item_TO_ItemManagement_1` FOREIGN KEY (
	`item_id`
)
REFERENCES `Item` (
	`id`
);

ALTER TABLE `PreTitleManagement` ADD CONSTRAINT `FK_PreTitle_TO_PreTitleManagement_1` FOREIGN KEY (
	`pre_title_id`
)
REFERENCES `PreTitle` (
	`id`
);

ALTER TABLE `PreTitleManagement` ADD CONSTRAINT `FK_Member_TO_PreTitleManagement_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `SuffixTitleManagement` ADD CONSTRAINT `FK_SuffixTitle_TO_SuffixTitleManagement_1` FOREIGN KEY (
	`suffix_title_id`
)
REFERENCES `SuffixTitle` (
	`id`
);

ALTER TABLE `SuffixTitleManagement` ADD CONSTRAINT `FK_Member_TO_SuffixTitleManagement_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `Mail` ADD CONSTRAINT `FK_Member_TO_Mail_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `Member` (
	`id`
);

ALTER TABLE `CopyOfMailbox` ADD CONSTRAINT `FK_CopyOfMember_TO_CopyOfMailbox_1` FOREIGN KEY (
	`id2`
)
REFERENCES `CopyOfMember` (
	`id`
);

ALTER TABLE `CopyOfItemManagement` ADD CONSTRAINT `FK_CopyOfItem_TO_CopyOfItemManagement_1` FOREIGN KEY (
	`id2`
)
REFERENCES `CopyOfItem` (
	`id`
);

ALTER TABLE `CopyOfItemManagement` ADD CONSTRAINT `FK_CopyOfMember_TO_CopyOfItemManagement_1` FOREIGN KEY (
	`id`
)
REFERENCES `CopyOfMember` (
	`id`
);

